using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public Vector3 direction;

    public float speed;

    public System.Action destroyed;

    private void Update()
    {
        transform.position += direction * speed * Time.deltaTime;
    }

    // event happens when ded
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!(destroyed == null))
        {
            destroyed.Invoke();
        }
        if (!gameObject.CompareTag("Player") && other.CompareTag("Player"))
        {
            ScoreKeeper.SubtractLives();
        }
        Destroy(gameObject);
    }

}

