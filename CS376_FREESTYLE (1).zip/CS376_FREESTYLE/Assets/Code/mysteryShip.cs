using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mysteryShip : MonoBehaviour
{
    public Projectile mysteryMissilePrefab;
    // Start is called before the first frame update
    Vector3 rightOffset = new Vector3(1, 0, 0);
    void Start()
    {
        InvokeRepeating(nameof(MissileAttack), 2.0f, 7.0f);
    }

    // Update is called once per frame
    private void MissileAttack()
    {
    Instantiate(mysteryMissilePrefab, rightOffset+transform.position, Quaternion.identity);
    }
}
