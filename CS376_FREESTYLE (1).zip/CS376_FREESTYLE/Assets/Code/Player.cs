using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // Start is called before the first frame update


    public float speed = 5.0f;

    public AudioClip[] shootClips;

    public Projectile laserPrefab;

    private bool activeLaser;

    private AudioSource audioSource;

    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.PlayOneShot(shootClips[4]);
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow) && transform.position.x < 4.5f)
        {
            this.transform.position += Vector3.right * this.speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.LeftArrow) && transform.position.x > -4.5f)
        {
            this.transform.position += Vector3.left * this.speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.UpArrow) && transform.position.y < -3.5f)
        {
            this.transform.position += Vector3.up * this.speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.DownArrow) && transform.position.y > -4.0f)
        {
            this.transform.position += Vector3.down * this.speed * Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Shoot();
        }
        if (ScoreKeeper.scoreText.text == "Score: 10")
        {
            ScoreKeeper.EndGame("You Win!");
        }


    }

    private void Shoot()
    {
        if (!activeLaser)
        {
            Projectile projectile = Instantiate(this.laserPrefab, this.transform.position, Quaternion.identity);
            audioSource.PlayOneShot(shootClips[Random.Range(0, 4)], 1.0f);
            projectile.destroyed += LaserDestroyed;
            activeLaser = true;

        }
    }

    private void LaserDestroyed()
    {
        activeLaser = false;
    }
}
