using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monsters : MonoBehaviour
{
    public Projectile mysteryMissilePrefab;
    public System.Action killed;
    private SpriteRenderer _spriteRenderer;
    private Vector2 center_point;
    private float theta;
    private void Start()
    {
        center_point = transform.position;
        InvokeRepeating(nameof(MissileAttack), 2.0f, 2.0f);
    }

    // Update is called once per frame
    private void MissileAttack()
    {
        Instantiate(mysteryMissilePrefab, transform.position, Quaternion.identity);
    }

    private void Update()
    {

        theta += Time.deltaTime;
        var offset = new Vector2(Mathf.Sin(theta), Mathf.Cos(theta)) * 1f;
        transform.position = center_point + offset;
    }

    private void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Laser"))
        {
            Destroy(this.gameObject);
            Scored();
        }
    }

    private void Scored()
    {
        ScoreKeeper.AddToScore(1);
    }
}


