using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ScoreKeeper : MonoBehaviour
{
    public static TextMeshProUGUI scoreText;
    public static TextMeshProUGUI livesText;
    public static TextMeshProUGUI gameOverText;
    private static int score;  // everyone has the same score
    private static int lives = 3;

    // Use this for initialization
    internal void Start()
    {
        scoreText = GameObject.Find("Score Text").GetComponent<TextMeshProUGUI>();
        livesText = GameObject.Find("Lives Text").GetComponent<TextMeshProUGUI>();
        gameOverText = GameObject.Find("Game Over Text").GetComponent<TextMeshProUGUI>();
        scoreText.text = "Score: 0";
        livesText.text = "Lives: 3";
        gameOverText.gameObject.SetActive(false);
    }

    public static void AddToScore(int points)
    {
        score += points;
        scoreText.text = String.Format("Score: {0}", score);
    }

    public static void SubtractLives()
    {
        lives--;
        livesText.text = String.Format("Lives: {0}", lives);
        if (lives == 0)
        {
            EndGame("You Lose!");
        }
    }

    public static void EndGame(string t)
    {
        gameOverText.text = t;
        gameOverText.gameObject.SetActive(true);
        Time.timeScale = 0;
    }
}
